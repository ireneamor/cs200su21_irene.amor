Name:				Irene Amor Mendez
Login: 				irene.amor
Student ID: 			540001720
Project: 			1.3 Draw Line
Time of implementation: 	1.5 hours
Time of testing: 		
Known Bugs: 
Comments:			It took me a while to be able to abstract the common parts