Name:				Irene Amor Mendez
Login: 				irene.amor
Student ID: 			540001720
Project: 			2.2 Draw Triangle
Time of implementation: 	2 hours
Time of testing: 		1 hour
Known Bugs: 
Comments:			